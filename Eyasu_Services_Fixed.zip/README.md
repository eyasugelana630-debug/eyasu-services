Eyasu Services full-stack app.
Run: npm install && npm start
Admin login: admin@eyasuservices.local
Admin password: Admin123!
